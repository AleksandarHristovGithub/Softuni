﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters.Knights
{
    public class Knight : Hero
    {
        public Knight(string username, int level)
              : base(username, level)
        {

        }
    }
}
