using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace BakeryOpenning
{
    public class Bakery
    {
        private List<Employee> data;
        public string Name { get; set; }
        public int Capacity { get; set; }

        public int Count => data.Count;
        public Bakery(string name, int capacity)
        {

            this.Name = name;
            this.Capacity = capacity;
            data = new List<Employee>();
        }
        public void Add(Employee employee)
        {
            if (Capacity > Count)
            {
                data.Add(employee);
            }
        }
        public bool Remove(string name)
        {
            Employee employee = data.Find(x => x.Name == name);
            if (employee != null)
            {
                data.Remove(employee);
                return true;
            }
            else
            {
                return false;
            }

        }
        public Employee GetOldestEmployee()
        {
            Employee getOldestEmployee = data.OrderByDescending(x => x.Name).First();
            return getOldestEmployee;
        
        }
        public Employee GetEmployee(string name)
        {
            Employee manufacturerToGet = data.FirstOrDefault(x => x.Name == name);


            if (manufacturerToGet != null)
            {
                return manufacturerToGet;
            }
            else
            {
                return null;
            }
        }
        public string Report()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Employees working at Bakery {Name}:").ToString();

            foreach (var car in this.data)
            {
                sb.AppendLine(car.ToString());
            }
            return sb.ToString().TrimEnd();
        }
    }
}