using System;
using System.Collections.Generic;
using System.Text;

namespace BakeryOpenning
{
    public class Employee
    {

        public string Name { get; set; }
        public int Age { get; set; }

        public string Country { get; set; }




        public Employee(string Name, int Age, string Country)
        {
            this.Name = Name;
            this.Age = Age;
            this.Country = Country;

        }

        public override string ToString()
        {
            StringBuilder myStringToReturn = new StringBuilder();
            myStringToReturn.AppendLine($"{Name} {Age} ({Country})");

            return myStringToReturn.ToString().TrimEnd();

        }
    }
}